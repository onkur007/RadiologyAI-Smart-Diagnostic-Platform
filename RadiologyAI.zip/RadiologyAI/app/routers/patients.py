"""
Patient-specific routes for uploading images, viewing reports, etc.
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.database import get_db
from app.models import User, RadiologyScan, MedicalReport, ImageModality, UserRole
from app.schemas import (
    RadiologyScanResponse,
    MedicalReportResponse,
    HealthSummaryResponse,
    ChatMessageCreate,
    ChatMessageResponse
)
from app.utils import get_current_user, save_upload_file
from app.services import gemini_service
import json

router = APIRouter(prefix="/patients", tags=["Patients"])


@router.get("/me", response_model=dict)
def get_my_profile(current_user: User = Depends(get_current_user)):
    """
    Get current patient's profile information.
    """
    if current_user.role != UserRole.PATIENT:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This endpoint is for patients only"
        )
    
    return {
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "phone": current_user.phone,
        "date_of_birth": current_user.date_of_birth,
        "role": current_user.role,
        "created_at": current_user.created_at
    }


@router.post("/upload-image", response_model=RadiologyScanResponse)
async def upload_radiology_image(
    file: UploadFile = File(...),
    modality: ImageModality = Form(...),
    description: str = Form(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Upload a radiology image (X-ray, CT, MRI).
    
    - **file**: Image file (jpg, jpeg, png)
    - **modality**: Type of scan (xray, ct, mri)
    - **description**: Optional description
    """
    if current_user.role != UserRole.PATIENT:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only patients can upload images"
        )
    
    # Save uploaded file
    file_path, relative_path = await save_upload_file(file, subfolder=f"patient_{current_user.id}")
    
    # Create database record
    scan = RadiologyScan(
        patient_id=current_user.id,
        modality=modality,
        image_path=relative_path,
        description=description,
        ai_analyzed=False
    )
    
    db.add(scan)
    db.commit()
    db.refresh(scan)
    
    return scan


@router.post("/scans/{scan_id}/analyze", response_model=RadiologyScanResponse)
async def analyze_scan(
    scan_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Request AI analysis of an uploaded scan.
    """
    # Get scan
    scan = db.query(RadiologyScan).filter(RadiologyScan.id == scan_id).first()
    
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    
    # Check ownership
    if scan.patient_id != current_user.id and current_user.role != UserRole.DOCTOR:
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Perform AI analysis
    full_path = f"uploads/{scan.image_path}"
    
    try:
        ai_result = await gemini_service.analyze_radiology_image(
            image_path=full_path,
            modality=scan.modality
        )
        
        # Update scan with AI results
        scan.ai_analyzed = True
        scan.detected_abnormalities = json.dumps(ai_result.get("abnormalities", []))
        scan.disease_classification = ai_result.get("disease_classification", "Unknown")
        scan.confidence_score = ai_result.get("confidence_score", 0.0)
        scan.risk_level = ai_result.get("risk_level", "MEDIUM")
        scan.ai_explanation = ai_result.get("explanation", "")
        
        db.commit()
        db.refresh(scan)
        
        return scan
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI analysis failed: {str(e)}")


@router.get("/scans", response_model=List[RadiologyScanResponse])
def get_my_scans(
    skip: int = 0,
    limit: int = 20,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get all scans uploaded by current patient.
    """
    if current_user.role != UserRole.PATIENT:
        raise HTTPException(status_code=403, detail="Patients only")
    
    scans = db.query(RadiologyScan)\
        .filter(RadiologyScan.patient_id == current_user.id)\
        .order_by(desc(RadiologyScan.upload_date))\
        .offset(skip)\
        .limit(limit)\
        .all()
    
    return scans


@router.get("/scans/{scan_id}", response_model=RadiologyScanResponse)
def get_scan_details(
    scan_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get detailed information about a specific scan.
    """
    scan = db.query(RadiologyScan).filter(RadiologyScan.id == scan_id).first()
    
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    
    # Check access
    if scan.patient_id != current_user.id and current_user.role not in [UserRole.DOCTOR, UserRole.ADMIN]:
        raise HTTPException(status_code=403, detail="Access denied")
    
    return scan


@router.get("/reports", response_model=List[MedicalReportResponse])
def get_my_reports(
    skip: int = 0,
    limit: int = 20,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get all medical reports for current patient.
    """
    if current_user.role != UserRole.PATIENT:
        raise HTTPException(status_code=403, detail="Patients only")
    
    reports = db.query(MedicalReport)\
        .filter(MedicalReport.patient_id == current_user.id)\
        .order_by(desc(MedicalReport.generated_at))\
        .offset(skip)\
        .limit(limit)\
        .all()
    
    return reports


@router.get("/health-summary", response_model=dict)
async def get_health_summary(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get AI-generated health summary for patient.
    """
    if current_user.role != UserRole.PATIENT:
        raise HTTPException(status_code=403, detail="Patients only")
    
    # Get patient data
    scans = db.query(RadiologyScan)\
        .filter(RadiologyScan.patient_id == current_user.id)\
        .order_by(desc(RadiologyScan.upload_date))\
        .limit(5)\
        .all()
    
    reports = db.query(MedicalReport)\
        .filter(MedicalReport.patient_id == current_user.id)\
        .order_by(desc(MedicalReport.generated_at))\
        .limit(5)\
        .all()
    
    # Prepare data for AI
    patient_data = {
        "name": current_user.full_name,
        "age": None,  # Calculate from date_of_birth if available
        "total_scans": len(scans),
        "total_reports": len(reports)
    }
    
    recent_reports_data = [
        {
            "date": str(r.generated_at),
            "diagnosis": r.diagnosis,
            "status": r.status.value
        }
        for r in reports
    ]
    
    # Generate summary
    summary = await gemini_service.generate_health_summary(patient_data, recent_reports_data)
    
    return {
        "patient_id": current_user.id,
        "total_scans": len(scans),
        "total_reports": len(reports),
        "summary": summary
    }

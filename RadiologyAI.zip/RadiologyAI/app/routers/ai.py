"""
AI service routes for chatbot, disease classification, etc.
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.database import get_db
from app.models import User, ChatSession, ChatMessage
from app.schemas import (
    ChatMessageCreate,
    ChatMessageResponse,
    DiseaseClassificationRequest,
    MedicineSuggestionResponse
)
from app.utils import get_current_user
from app.services import gemini_service

router = APIRouter(prefix="/ai", tags=["AI Services"])


@router.post("/chat", response_model=ChatMessageResponse)
async def chat_with_ai(
    message_data: ChatMessageCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Chat with AI assistant. Maintains conversation context.
    """
    # Get or create chat session
    session = None
    
    if message_data.session_id:
        session = db.query(ChatSession)\
            .filter(
                ChatSession.id == message_data.session_id,
                ChatSession.user_id == current_user.id
            )\
            .first()
    
    if not session:
        # Create new session
        session = ChatSession(user_id=current_user.id)
        db.add(session)
        db.commit()
        db.refresh(session)
    
    # Save user message
    user_message = ChatMessage(
        session_id=session.id,
        sender="user",
        message=message_data.message
    )
    db.add(user_message)
    db.commit()
    
    # Get conversation history
    history = db.query(ChatMessage)\
        .filter(ChatMessage.session_id == session.id)\
        .order_by(ChatMessage.timestamp)\
        .all()
    
    history_data = [
        {"sender": msg.sender, "message": msg.message}
        for msg in history
    ]
    
    # Get AI response
    ai_response_text = await gemini_service.chat_response(
        user_message=message_data.message,
        conversation_history=history_data
    )
    
    # Save AI response
    ai_message = ChatMessage(
        session_id=session.id,
        sender="ai",
        message=ai_response_text
    )
    db.add(ai_message)
    db.commit()
    db.refresh(ai_message)
    
    return ai_message


@router.get("/chat/sessions", response_model=List[dict])
def get_chat_sessions(
    skip: int = 0,
    limit: int = 20,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get all chat sessions for current user.
    """
    sessions = db.query(ChatSession)\
        .filter(ChatSession.user_id == current_user.id)\
        .order_by(desc(ChatSession.session_start))\
        .offset(skip)\
        .limit(limit)\
        .all()
    
    return [
        {
            "id": s.id,
            "session_start": s.session_start,
            "session_end": s.session_end,
            "message_count": len(s.messages)
        }
        for s in sessions
    ]


@router.get("/chat/sessions/{session_id}/messages", response_model=List[ChatMessageResponse])
def get_session_messages(
    session_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get all messages from a specific chat session.
    """
    session = db.query(ChatSession)\
        .filter(
            ChatSession.id == session_id,
            ChatSession.user_id == current_user.id
        )\
        .first()
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    messages = db.query(ChatMessage)\
        .filter(ChatMessage.session_id == session_id)\
        .order_by(ChatMessage.timestamp)\
        .all()
    
    return messages


@router.post("/classify-disease", response_model=dict)
async def classify_disease(
    request: DiseaseClassificationRequest,
    current_user: User = Depends(get_current_user)
):
    """
    Classify disease based on symptoms and medical data.
    """
    result = await gemini_service.classify_disease(
        symptoms=request.symptoms,
        medical_history=request.medical_history,
        scan_findings=request.scan_findings
    )
    
    return result


@router.post("/suggest-medicines", response_model=dict)
async def suggest_medicines(
    disease_classification: str,
    symptoms: str,
    patient_age: Optional[int] = None,
    current_user: User = Depends(get_current_user)
):
    """
    Get AI-based medicine suggestions.
    
    **Important**: These are informational suggestions only.
    Always consult a healthcare provider before taking any medication.
    """
    result = await gemini_service.suggest_medicines(
        disease_classification=disease_classification,
        symptoms=symptoms,
        patient_age=patient_age
    )
    
    return result


@router.post("/assess-risk", response_model=dict)
async def assess_risk(
    findings: List[str],
    medical_history: Optional[str] = None,
    current_user: User = Depends(get_current_user)
):
    """
    Assess patient risk profile based on findings.
    """
    result = await gemini_service.assess_risk_profile(
        findings=findings,
        medical_history=medical_history
    )
    
    return result

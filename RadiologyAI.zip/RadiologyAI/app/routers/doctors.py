"""
Doctor-specific routes for reviewing patients, validating reports, etc.
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.database import get_db
from app.models import User, RadiologyScan, MedicalReport, UserRole, ReportStatus
from app.schemas import (
    RadiologyScanResponse,
    MedicalReportResponse,
    MedicalReportCreate,
    DoctorValidation
)
from app.utils import get_current_user
from app.services import gemini_service
import json

router = APIRouter(prefix="/doctors", tags=["Doctors"])


@router.get("/patients", response_model=List[dict])
def get_assigned_patients(
    skip: int = 0,
    limit: int = 50,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get list of patients with pending or recent scans.
    Doctors can see all patients in the system.
    """
    if current_user.role != UserRole.DOCTOR:
        raise HTTPException(status_code=403, detail="Doctors only")
    
    # Get patients who have uploaded scans
    patients = db.query(User)\
        .filter(User.role == UserRole.PATIENT)\
        .offset(skip)\
        .limit(limit)\
        .all()
    
    patient_list = []
    for patient in patients:
        # Count scans and reports
        scan_count = db.query(RadiologyScan)\
            .filter(RadiologyScan.patient_id == patient.id)\
            .count()
        
        report_count = db.query(MedicalReport)\
            .filter(MedicalReport.patient_id == patient.id)\
            .count()
        
        pending_reports = db.query(MedicalReport)\
            .filter(
                MedicalReport.patient_id == patient.id,
                MedicalReport.status == ReportStatus.PENDING
            )\
            .count()
        
        patient_list.append({
            "id": patient.id,
            "username": patient.username,
            "full_name": patient.full_name,
            "email": patient.email,
            "total_scans": scan_count,
            "total_reports": report_count,
            "pending_reports": pending_reports
        })
    
    return patient_list


@router.get("/patients/{patient_id}/scans", response_model=List[RadiologyScanResponse])
def get_patient_scans(
    patient_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get all scans for a specific patient.
    """
    if current_user.role != UserRole.DOCTOR:
        raise HTTPException(status_code=403, detail="Doctors only")
    
    scans = db.query(RadiologyScan)\
        .filter(RadiologyScan.patient_id == patient_id)\
        .order_by(desc(RadiologyScan.upload_date))\
        .all()
    
    return scans


@router.get("/patients/{patient_id}/reports", response_model=List[MedicalReportResponse])
def get_patient_reports(
    patient_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get all reports for a specific patient.
    """
    if current_user.role != UserRole.DOCTOR:
        raise HTTPException(status_code=403, detail="Doctors only")
    
    reports = db.query(MedicalReport)\
        .filter(MedicalReport.patient_id == patient_id)\
        .order_by(desc(MedicalReport.generated_at))\
        .all()
    
    return reports


@router.post("/generate-report", response_model=MedicalReportResponse)
async def generate_report(
    report_data: MedicalReportCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Generate AI-assisted medical report for a patient.
    """
    if current_user.role != UserRole.DOCTOR:
        raise HTTPException(status_code=403, detail="Doctors only")
    
    # Get patient
    patient = db.query(User).filter(User.id == report_data.patient_id).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    
    # Get scan if provided
    scan = None
    if report_data.scan_id:
        scan = db.query(RadiologyScan).filter(RadiologyScan.id == report_data.scan_id).first()
        if not scan:
            raise HTTPException(status_code=404, detail="Scan not found")
    
    # Prepare data for AI report generation
    patient_info = {
        "name": patient.full_name,
        "id": patient.id,
        "email": patient.email
    }
    
    scan_info = {}
    ai_findings = {}
    
    if scan:
        scan_info = {
            "modality": scan.modality.value,
            "date": str(scan.upload_date),
            "description": scan.description
        }
        
        if scan.ai_analyzed:
            ai_findings = {
                "abnormalities": json.loads(scan.detected_abnormalities) if scan.detected_abnormalities else [],
                "classification": scan.disease_classification,
                "confidence": scan.confidence_score,
                "risk_level": scan.risk_level.value if scan.risk_level else None,
                "explanation": scan.ai_explanation
            }
    
    # Generate report using AI
    report_content = await gemini_service.generate_medical_report(
        patient_info,
        scan_info,
        ai_findings
    )
    
    # Create report in database
    report = MedicalReport(
        patient_id=report_data.patient_id,
        scan_id=report_data.scan_id,
        doctor_id=current_user.id,
        report_type=report_data.report_type,
        ai_generated_content=report_content,
        status=ReportStatus.PENDING
    )
    
    db.add(report)
    db.commit()
    db.refresh(report)
    
    return report


@router.put("/reports/{report_id}/validate", response_model=MedicalReportResponse)
def validate_report(
    report_id: int,
    validation: DoctorValidation,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Validate or reject an AI-generated report with doctor's notes.
    """
    if current_user.role != UserRole.DOCTOR:
        raise HTTPException(status_code=403, detail="Doctors only")
    
    # Get report
    report = db.query(MedicalReport).filter(MedicalReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    # Update report with doctor validation
    report.doctor_id = current_user.id
    report.doctor_notes = validation.doctor_notes
    report.diagnosis = validation.diagnosis
    report.recommended_treatment = validation.recommended_treatment
    report.medicine_suggestions = validation.medicine_suggestions
    report.status = validation.status
    
    from datetime import datetime
    report.validated_at = datetime.utcnow()
    
    db.commit()
    db.refresh(report)
    
    return report


@router.get("/pending-reports", response_model=List[MedicalReportResponse])
def get_pending_reports(
    skip: int = 0,
    limit: int = 50,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get all pending reports that need doctor validation.
    """
    if current_user.role != UserRole.DOCTOR:
        raise HTTPException(status_code=403, detail="Doctors only")
    
    reports = db.query(MedicalReport)\
        .filter(MedicalReport.status == ReportStatus.PENDING)\
        .order_by(desc(MedicalReport.generated_at))\
        .offset(skip)\
        .limit(limit)\
        .all()
    
    return reports


@router.post("/suggest-medicines/{patient_id}", response_model=dict)
async def suggest_medicines_for_patient(
    patient_id: int,
    disease_classification: str,
    symptoms: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get AI-based medicine suggestions for a patient.
    """
    if current_user.role != UserRole.DOCTOR:
        raise HTTPException(status_code=403, detail="Doctors only")
    
    # Verify patient exists
    patient = db.query(User).filter(User.id == patient_id).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    
    # Get AI suggestions
    suggestions = await gemini_service.suggest_medicines(
        disease_classification=disease_classification,
        symptoms=symptoms
    )
    
    return suggestions

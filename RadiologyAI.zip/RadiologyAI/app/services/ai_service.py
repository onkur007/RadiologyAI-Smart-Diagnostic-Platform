"""
Gemini AI integration service.
Handles all AI-related operations using Google's Gemini API.
"""
import google.generativeai as genai
from typing import Dict, Optional, List
import json
from PIL import Image

from app.config import settings
from app.models import ImageModality, RiskLevel

# Configure Gemini API
genai.configure(api_key=settings.gemini_api_key)


class GeminiAIService:
    """Service class for Gemini AI operations"""
    
    def __init__(self):
        """Initialize Gemini models"""
        self.text_model = genai.GenerativeModel('gemini-pro')
        self.vision_model = genai.GenerativeModel('gemini-pro-vision')
    
    async def analyze_radiology_image(
        self,
        image_path: str,
        modality: ImageModality,
        patient_context: Optional[str] = None
    ) -> Dict:
        """
        Analyze a radiology image using Gemini Vision API.
        
        Args:
            image_path: Path to the image file
            modality: Type of scan (XRAY, CT, MRI)
            patient_context: Optional patient medical history
            
        Returns:
            Dict containing analysis results
        """
        try:
            # Load image
            img = Image.open(image_path)
            
            # Construct detailed prompt
            prompt = f"""
            You are an expert radiologist AI assistant. Analyze this {modality.value.upper()} scan image.
            
            Please provide:
            1. Detailed description of visible anatomical structures
            2. Any abnormalities or suspicious findings detected
            3. Possible disease classification or conditions
            4. Confidence level (0.0 to 1.0)
            5. Risk assessment (LOW, MEDIUM, HIGH)
            6. Recommendations for further investigation
            
            {f"Patient Context: {patient_context}" if patient_context else ""}
            
            Provide response in the following JSON format:
            {{
                "description": "detailed anatomical description",
                "abnormalities": ["list of abnormalities found"],
                "disease_classification": "primary suspected condition",
                "confidence_score": 0.0-1.0,
                "risk_level": "LOW/MEDIUM/HIGH",
                "explanation": "detailed medical explanation",
                "recommendations": ["list of recommendations"]
            }}
            
            IMPORTANT: Be thorough but always include medical disclaimer that this is AI-assisted analysis 
            and requires professional validation.
            """
            
            # Generate content
            response = self.vision_model.generate_content([prompt, img])
            
            # Parse response
            result = self._parse_ai_response(response.text)
            
            return result
            
        except Exception as e:
            return {
                "error": str(e),
                "description": "AI analysis failed",
                "abnormalities": [],
                "disease_classification": "Unknown",
                "confidence_score": 0.0,
                "risk_level": "MEDIUM",
                "explanation": f"Error during analysis: {str(e)}",
                "recommendations": ["Manual review required"]
            }
    
    async def classify_disease(
        self,
        symptoms: str,
        medical_history: Optional[str] = None,
        scan_findings: Optional[str] = None
    ) -> Dict:
        """
        Classify disease based on symptoms and medical data.
        
        Args:
            symptoms: Patient symptoms description
            medical_history: Optional patient medical history
            scan_findings: Optional radiology scan findings
            
        Returns:
            Dict with disease classification
        """
        try:
            prompt = f"""
            As a medical AI assistant, analyze the following patient information and provide disease classification:
            
            Symptoms: {symptoms}
            {f"Medical History: {medical_history}" if medical_history else ""}
            {f"Scan Findings: {scan_findings}" if scan_findings else ""}
            
            Provide analysis in JSON format:
            {{
                "primary_diagnosis": "most likely condition",
                "differential_diagnoses": ["other possible conditions"],
                "confidence_score": 0.0-1.0,
                "severity": "mild/moderate/severe",
                "risk_factors": ["identified risk factors"],
                "explanation": "detailed medical explanation",
                "recommended_tests": ["additional tests needed"]
            }}
            
            Include appropriate medical disclaimers.
            """
            
            response = self.text_model.generate_content(prompt)
            result = self._parse_ai_response(response.text)
            
            return result
            
        except Exception as e:
            return {
                "error": str(e),
                "primary_diagnosis": "Analysis incomplete",
                "explanation": f"Error: {str(e)}"
            }
    
    async def generate_medical_report(
        self,
        patient_info: Dict,
        scan_info: Dict,
        ai_findings: Dict
    ) -> str:
        """
        Generate structured medical report.
        
        Args:
            patient_info: Patient details
            scan_info: Scan information
            ai_findings: AI analysis results
            
        Returns:
            Formatted medical report text
        """
        try:
            prompt = f"""
            Generate a professional medical radiology report based on:
            
            Patient Information:
            {json.dumps(patient_info, indent=2)}
            
            Scan Information:
            {json.dumps(scan_info, indent=2)}
            
            AI Findings:
            {json.dumps(ai_findings, indent=2)}
            
            Generate a structured medical report with:
            1. Patient Demographics
            2. Examination Details
            3. Clinical Indication
            4. Findings
            5. Impression
            6. Recommendations
            
            Use professional medical terminology and standard report format.
            Include disclaimer that AI-generated content requires physician validation.
            """
            
            response = self.text_model.generate_content(prompt)
            return response.text
            
        except Exception as e:
            return f"Report generation failed: {str(e)}"
    
    async def chat_response(
        self,
        user_message: str,
        conversation_history: Optional[List[Dict]] = None
    ) -> str:
        """
        Generate chatbot response.
        
        Args:
            user_message: User's message
            conversation_history: Previous messages for context
            
        Returns:
            AI response text
        """
        try:
            # Build context from history
            context = ""
            if conversation_history:
                for msg in conversation_history[-5:]:  # Last 5 messages
                    context += f"{msg['sender']}: {msg['message']}\n"
            
            prompt = f"""
            You are a helpful medical AI assistant for a radiology platform.
            
            Previous conversation:
            {context}
            
            User: {user_message}
            
            Provide helpful, accurate medical information while:
            1. Being empathetic and clear
            2. Using simple language when possible
            3. Including medical disclaimers for serious queries
            4. Encouraging professional medical consultation
            5. Never providing emergency medical advice
            
            Assistant:
            """
            
            response = self.text_model.generate_content(prompt)
            return response.text
            
        except Exception as e:
            return f"I apologize, but I encountered an error: {str(e)}. Please try again or contact support."
    
    async def suggest_medicines(
        self,
        disease_classification: str,
        symptoms: str,
        patient_age: Optional[int] = None
    ) -> Dict:
        """
        Suggest medicines based on disease classification.
        
        Args:
            disease_classification: Diagnosed condition
            symptoms: Patient symptoms
            patient_age: Optional patient age
            
        Returns:
            Dict with medicine suggestions
        """
        try:
            prompt = f"""
            As a medical AI assistant, suggest commonly prescribed medicines for:
            
            Condition: {disease_classification}
            Symptoms: {symptoms}
            {f"Patient Age: {patient_age}" if patient_age else ""}
            
            Provide suggestions in JSON format:
            {{
                "medicines": [
                    {{
                        "name": "medicine name",
                        "purpose": "what it treats",
                        "general_usage": "typical usage information",
                        "precautions": "important precautions"
                    }}
                ],
                "disclaimer": "Important medical disclaimer"
            }}
            
            CRITICAL: Include strong disclaimer about consulting healthcare provider.
            Do NOT provide specific dosages.
            """
            
            response = self.text_model.generate_content(prompt)
            result = self._parse_ai_response(response.text)
            
            return result
            
        except Exception as e:
            return {
                "medicines": [],
                "disclaimer": "Medicine suggestion unavailable. Please consult a healthcare provider.",
                "error": str(e)
            }
    
    async def generate_health_summary(
        self,
        patient_data: Dict,
        recent_reports: List[Dict]
    ) -> str:
        """
        Generate comprehensive health summary.
        
        Args:
            patient_data: Patient information
            recent_reports: List of recent medical reports
            
        Returns:
            Health summary text
        """
        try:
            prompt = f"""
            Generate a concise health summary for:
            
            Patient Data:
            {json.dumps(patient_data, indent=2)}
            
            Recent Reports:
            {json.dumps(recent_reports, indent=2)}
            
            Provide:
            1. Current health status overview
            2. Key findings from recent scans
            3. Risk factors identified
            4. Recommended follow-up actions
            5. Overall health trajectory
            
            Keep it clear and patient-friendly while being medically accurate.
            """
            
            response = self.text_model.generate_content(prompt)
            return response.text
            
        except Exception as e:
            return f"Health summary generation failed: {str(e)}"
    
    async def assess_risk_profile(
        self,
        findings: List[str],
        medical_history: Optional[str] = None
    ) -> Dict:
        """
        Assess patient risk profile.
        
        Args:
            findings: List of medical findings
            medical_history: Patient medical history
            
        Returns:
            Risk assessment dict
        """
        try:
            prompt = f"""
            Assess patient risk profile based on:
            
            Findings: {json.dumps(findings)}
            {f"Medical History: {medical_history}" if medical_history else ""}
            
            Provide risk assessment in JSON:
            {{
                "overall_risk": "LOW/MEDIUM/HIGH",
                "risk_factors": ["identified factors"],
                "priority_level": "routine/urgent/immediate",
                "recommendations": ["recommended actions"],
                "explanation": "detailed risk explanation"
            }}
            """
            
            response = self.text_model.generate_content(prompt)
            result = self._parse_ai_response(response.text)
            
            return result
            
        except Exception as e:
            return {
                "overall_risk": "MEDIUM",
                "risk_factors": [],
                "explanation": f"Risk assessment error: {str(e)}"
            }
    
    def _parse_ai_response(self, response_text: str) -> Dict:
        """
        Parse AI response text to extract JSON.
        
        Args:
            response_text: Raw AI response
            
        Returns:
            Parsed dictionary
        """
        try:
            # Try to find JSON in response
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}') + 1
            
            if start_idx != -1 and end_idx > start_idx:
                json_str = response_text[start_idx:end_idx]
                return json.loads(json_str)
            
            # If no JSON found, return text as-is
            return {"response": response_text}
            
        except json.JSONDecodeError:
            return {"response": response_text}


# Create global instance
gemini_service = GeminiAIService()
